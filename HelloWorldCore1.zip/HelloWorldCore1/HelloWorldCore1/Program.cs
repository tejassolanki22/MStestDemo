﻿using System;

namespace HelloWorldCore1
{
   public class Program
    {
        public  static void Main()
        {
            Console.WriteLine("Hello World!");
        }

        
    }
}
